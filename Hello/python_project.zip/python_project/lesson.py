import random
from getpass import getpass
#
# mounth = "Февраль";
# budet = 100000;
# def vacation(mounth, budet):
#
# 	message = ""
# 	if mounth in ["Январь", "Февраль"]:
# 		if budet >= 450000:
# 			message = "Выбираем Хоккайдо! Бюджет позволяет арендовать отличное жилье прям у подъемника"
# 		elif budet >= 300000:
# 			message = "Отличный вариант - курорты Нагано. Оптимальное соотношение цены и качества"
# 		else:
# 			message = "Для пикового сезона денег маловато"
#
# 	elif mounth == "Март":
# 		message = "В марте начинается весенее катание. Снега чуть меньше, но погода солнечная, а цены на ски-пассы приятнее!"
# 	else:
# 		message = "Это не самый популярный сезон для сноуборда. возможно стоит перенести даты"
#
# 	return message
#
# print(vacation(mounth, budet))
#
# def proverka():
# 	for i in range(10):
# 		while i <= 5:
# 			print(i)
# 			i += 1
# 		else:
# 			break
#
# print(proverka())
#
#
# target_amount = 1500;
# current_amount = 0;
#
# while current_amount < target_amount:
# 	current_amount += int(input("Введи сколько положить в копилку"))
# 	print(f'Осталось еще накопить {target_amount - current_amount}')
# else:
# 	print("Нужная сумма собрана! Собираем чемоданы")1

# 5.Банкомат где начальная сумма 1000
# есть меню где 1- пополнить 2-снять 3-показать баланс 0-выход
# при снятии больше баланса отказ 
# при неверной команде пропустить
# при 0 выйти и показать итоговый баланс

